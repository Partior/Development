<<<<<<< HEAD
%% Goals
% This script defines the goals set by Graham to be for our aircraft

Wto=17000;  % lbs
P=1500;     % hp
V_c=265;    % mph
WS=40;      % wingloading
=======
%% Goals
% This script defines the goals set by Graham to be for our aircraft

Wto=17000;  % lbs
P=1500;     % hp
V_c=265;    % mph
WS=40;      % wingloading
>>>>>>> c95d0c656b92fc28985e433b06102151be39b9c5
R=1100;     % nm